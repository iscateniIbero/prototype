<?php 
require_once '../../../general/config/db.php';
require_once '../../../general/functions/functions.php';
?>
<div class="graphicSizePatrimony">
  <canvas id="showGraphPatrimony" width="100vw" height="60vh"></canvas>
</div>
<script src="<?php echo PATH; ?>general/public/js/graphPatrimony.js"></script>