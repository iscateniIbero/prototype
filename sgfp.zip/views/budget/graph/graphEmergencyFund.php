<?php 
require_once '../../../general/config/db.php';
require_once '../../../general/functions/functions.php';
?>
<canvas id="showGraphEmergencyFund" width="100vw" height="60vh"></canvas>
<script src="<?php echo PATH; ?>general/public/js/graphEmergencyFund.js"></script>