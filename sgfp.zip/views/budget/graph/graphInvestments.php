<?php 
require_once '../../../general/config/db.php';
require_once '../../../general/functions/functions.php';
?>
<div class="graphicSizeInvestments">
    <canvas id="showGraphInvestments" width="100vw" height="40vh"></canvas>
</div>
<script src="<?php echo PATH; ?>general/public/js/graphInvestments.js"></script>