<?php 
require_once '../../../general/config/db.php';
require_once '../../../general/functions/functions.php';
?>
<canvas id="showGraphSaving" width="100vw" height="60vh"></canvas>
<script src="<?php echo PATH; ?>general/public/js/graphSaving.js"></script>