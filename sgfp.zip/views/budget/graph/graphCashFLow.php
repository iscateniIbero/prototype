<?php 
require_once '../../../general/config/db.php';
require_once '../../../general/functions/functions.php';
?>
<canvas id="showGraphCashFlow" width="400" height="100vh"></canvas>
<script src="<?php echo PATH; ?>general/public/js/graphCashFlow.js"></script>