<?php
require_once '../../config/db.php';
require_once '../functions.php';
echo cancelIncomeSource($_POST['id']); 